const admin = require('firebase-admin');

const serviceAccount = require('./secrets.json');


admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

function getAllUserToCSV(){
  return new Promise((resolve,reject) =>{
    db.collection('users').get()
    .then((snapshot) => {
      let csvFile = `nome,email,data_nascimento,sexo,formacao,outra_formacao,cidade_nome,cidade_id,estado_sigla,estado_id,estado_nome,area_atuacao,outra_area_atuacao,Tem experiêncial profissional com violência doméstica contra criança?,Tem experiência profissional com classificações de Enfermagem?,outra_experiencia,favoritos\n`;

      snapshot.forEach((doc) => {
        let user = doc.data();
        csvFile += `${user.name},${doc.id},${user.dob},${user.sex},${user.formation},${user.otherFormation},${user.selectedCity.nome},${user.selectedCity.id},${user.selectedState.sigla},${user.selectedState.id},${user.selectedState.nome},${user.actionArea},${user.otherArea},${user.pastXp},${user.pastXpClass},${user.therPastXpClass},`;

        let favorites = "";
        if(user.favorites){
          favorites = user.favorites.join([separador = ' '])
        }

        csvFile += favorites + '\n';
      })
      console.log(csvFile);
    })
    .catch((err) => {
      reject(err);
    }); 
  })
}

getAllUserToCSV()


